# Max Player Clone - Fast Video & Audio Player
## APK বানানোর নিয়ম
1. ZIP unzip করো
2. Android Studio তে Open করো -> Sync Gradle
3. অথবা Terminal: flutter pub get && flutter build apk --release
APK পাবে: build/app/outputs/flutter-apk/app-release.apk

## ফিচার
- Instant open, lazy scan
- MediaKit HW decode, fast seek - double-tap এ re-buffer নেই
- Double-tap L/R seek (5/10/15/20/30 sec, মাঝের band এ শুধু)
- Swipe: বাম = Brightness, ডান = Volume (system), কোনায় কাজ করবে না
- Resume, Auto-play next, PiP, Audio-only, Equalizer, Orientation modes
- Bottom Nav: Home/Video, Audio, Playlist, Settings
- FAB Resume: শেষ ভিডিও/অডিও, লোগো zoom করা
- Themes: Dark/Light/System/Blue/Purple/Green + Font size + Sort Date/Name/Size
