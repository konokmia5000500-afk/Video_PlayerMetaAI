# GitHub থেকে APK পাওয়ার নিয়ম - ২ মিনিট

## ১. GitHub এ আপলোড
1. github.com এ গিয়ে New Repository বানাও - নাম: MaxPlayer
2. এই ZIP টা Unzip করে সব ফাইল + .github ফোল্ডার সহ Upload করো
   - খেয়াল: .github ফোল্ডারটা লুকানো থাকতে পারে, Zip থেকে সব সিলেক্ট করে আপলোড করলে চলে আসবে
3. Commit / Push করো

## ২. APK বানানো অটো শুরু হবে
- উপরে Actions ট্যাবে যাও
- "Build APK - Symphony Innova 10 (arm64)" নামে একটা Run চলবে
- ৩-৫ মিনিট অপেক্ষা করো, সবুজ টিক আসলে শেষ

## ৩. ডাউনলোড
- ওই Run এর ভিতরে নিচে Artifacts এ পাবে:
  MaxPlayer-Inova10-APK
- ওটা ডাউনলোড করলে একটা ZIP পাবে
- ওই ZIP খুললে ভিতরে শুধু ১টা ফাইল থাকবে:
  MaxPlayer-Inova10-arm64.apk

## কেন ১টাই APK?
- Symphony Innova 10 এর চিপসেট MediaTek Helio G35, 64-bit ARM Cortex-A53
- তাই flutter build apk --release --target-platform android-arm64 ব্যবহার করা
- --split-per-abi ব্যবহার করিনি, তাই ৩টা APK হবে না
- universal APK ও বানাইনি, তাই সাইজ ছোট + ফাস্ট হবে

## ফোনে ইনস্টল
ফোনে APK টা পাঠিয়ে Install করো। Unknown sources চাইলে Allow করো।
