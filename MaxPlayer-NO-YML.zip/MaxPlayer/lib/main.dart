import 'package:flutter/material.dart';
import 'package:media_kit/media_kit.dart';
import 'package:provider/provider.dart';
import 'services/settings_service.dart';
import 'screens/home_screen.dart';
import 'screens/playlist_screen.dart';
import 'screens/settings_screen.dart';
import 'screens/player_screen.dart';
import 'models/media_item.dart';
void main() { WidgetsFlutterBinding.ensureInitialized(); MediaKit.ensureInitialized(); runApp(ChangeNotifierProvider(create: (_) => AppSettings()..load(), child: const MyApp())); }
class MyApp extends StatelessWidget { const MyApp({super.key}); @override Widget build(BuildContext context) { final s = context.watch<AppSettings>(); return MaterialApp(title: 'Max Player', debugShowCheckedModeBanner: false, themeMode: s.themeModeEnum, theme: ThemeData(useMaterial3: true, brightness: Brightness.light, colorSchemeSeed: s.accent), darkTheme: ThemeData(useMaterial3: true, brightness: Brightness.dark, colorSchemeSeed: s.accent), home: const MainShell()); } }
class MainShell extends StatefulWidget { const MainShell({super.key}); @override State<MainShell> createState() => _MainShellState(); }
class _MainShellState extends State<MainShell> {
  int idx = 0;
  @override Widget build(BuildContext context) {
    final s = context.watch<AppSettings>();
    final pages = [const HomeScreen(audioOnly: false), const HomeScreen(audioOnly: true), const PlaylistScreen(), const SettingsScreen()];
    return Scaffold(
      appBar: AppBar(title: Row(children: [Image.asset('assets/logo.png', width: 28, height: 28), const SizedBox(width: 8), const Text('Max Player')]), actions: [PopupMenuButton<String>(onSelected: (v) { s.sortBy = v; s.save(); }, itemBuilder: (c) => [const PopupMenuItem(value: 'date', child: Text('Sort by Date')), const PopupMenuItem(value: 'name', child: Text('Sort by Name')), const PopupMenuItem(value: 'size', child: Text('Sort by Size'))], icon: const Icon(Icons.sort)), IconButton(icon: const Icon(Icons.search), onPressed: () {})]),
      body: pages[idx],
      floatingActionButton: s.lastPath.isEmpty ? null : FloatingActionButton.extended(onPressed: () { final it = MediaItem(path: s.lastPath, name: s.lastPath.split('/').last, folder: '', isAudio: s.lastIsAudio, size: 0, modified: DateTime.now()); Navigator.push(context, MaterialPageRoute(builder: (_) => PlayerScreen(item: it, queue: [it]))); }, backgroundColor: s.accent, icon: ClipOval(child: Image.asset('assets/logo.png', width: 28, height: 28, fit: BoxFit.cover)), label: const Text('Resume', style: TextStyle(color: Colors.white))),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
      bottomNavigationBar: NavigationBar(selectedIndex: idx, onDestinationSelected: (i) => setState(() => idx = i), destinations: const [NavigationDestination(icon: Icon(Icons.home), label: 'Home'), NavigationDestination(icon: Icon(Icons.music_note), label: 'Audio'), NavigationDestination(icon: Icon(Icons.playlist_play), label: 'Playlist'), NavigationDestination(icon: Icon(Icons.settings), label: 'Settings')]),
    );
  }
}
