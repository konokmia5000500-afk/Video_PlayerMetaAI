class MediaItem {
  final String path; final String name; final String folder;
  final bool isAudio; final int size; final DateTime modified;
  MediaItem({required this.path, required this.name, required this.folder, required this.isAudio, required this.size, required this.modified});
}
class Playlist {
  String name; List<String> paths;
  Playlist({required this.name, required this.paths});
  Map<String, dynamic> toJson() => {'name': name, 'paths': paths};
  factory Playlist.fromJson(Map<String, dynamic> j) => Playlist(name: j['name'], paths: List<String>.from(j['paths']));
}
