import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/media_item.dart';
import '../services/media_service.dart';
import '../services/settings_service.dart';
import 'player_screen.dart';
class HomeScreen extends StatefulWidget { final bool audioOnly; const HomeScreen({super.key, this.audioOnly = false}); @override State<HomeScreen> createState() => _HomeScreenState(); }
class _HomeScreenState extends State<HomeScreen> {
  List<MediaItem> items = []; bool loading = true;
  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async { final list = await MediaService.scan(); if (mounted) setState(() { items = list; loading = false; }); }
  @override Widget build(BuildContext context) {
    final s = context.watch<AppSettings>();
    final groups = MediaService.groupByFolder(items, widget.audioOnly);
    final folders = groups.keys.toList();
    folders.sort((a, b) => s.sortBy == 'name' ? a.compareTo(b) : (groups[b]?.length ?? 0).compareTo(groups[a]?.length ?? 0));
    if (loading) return const Center(child: CircularProgressIndicator());
    if (folders.isEmpty) return const Center(child: Text('No media found. Grant storage permission.'));
    return ListView.builder(itemCount: folders.length, itemBuilder: (c, i) {
      final f = folders[i]; final list = groups[f]!;
      return ListTile(leading: Container(width: 48, height: 48, decoration: BoxDecoration(color: s.accent.withOpacity(0.15), borderRadius: BorderRadius.circular(10)), child: Icon(widget.audioOnly ? Icons.music_note : Icons.folder, color: s.accent)), title: Text(f.split('/').last, style: TextStyle(fontSize: s.fontSize, fontWeight: FontWeight.w600)), subtitle: Text('${list.length} files'), trailing: const Icon(Icons.chevron_right), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => FolderDetailScreen(folder: f, items: list))));
    });
  }
}
class FolderDetailScreen extends StatelessWidget {
  final String folder; final List<MediaItem> items;
  const FolderDetailScreen({super.key, required this.folder, required this.items});
  @override Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text(folder.split('/').last)), body: ListView.builder(itemCount: items.length, itemBuilder: (c, i) { final it = items[i]; return ListTile(leading: Icon(it.isAudio ? Icons.music_note : Icons.play_circle_fill, color: Colors.blue, size: 36), title: Text(it.name, maxLines: 1, overflow: TextOverflow.ellipsis), subtitle: Text('${(it.size / 1024 / 1024).toStringAsFixed(1)} MB'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PlayerScreen(item: it, queue: items)))); }));
  }
}
