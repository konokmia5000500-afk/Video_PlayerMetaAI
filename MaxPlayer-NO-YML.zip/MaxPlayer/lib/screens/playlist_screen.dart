import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/media_item.dart';
class PlaylistScreen extends StatefulWidget { const PlaylistScreen({super.key}); @override State<PlaylistScreen> createState() => _PlaylistScreenState(); }
class _PlaylistScreenState extends State<PlaylistScreen> {
  List<Playlist> pls = [];
  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async { final p = await SharedPreferences.getInstance(); final raw = p.getStringList('playlists') ?? []; setState(() => pls = raw.map((e) => Playlist.fromJson(jsonDecode(e))).toList()); }
  Future<void> _save() async { final p = await SharedPreferences.getInstance(); await p.setStringList('playlists', pls.map((e) => jsonEncode(e.toJson())).toList()); }
  @override Widget build(BuildContext context) {
    return Scaffold(body: pls.isEmpty ? const Center(child: Text('No playlists yet. Create one.')) : ListView.builder(itemCount: pls.length, itemBuilder: (c, i) => ListTile(leading: const Icon(Icons.playlist_play), title: Text(pls[i].name), subtitle: Text('${pls[i].paths.length} items'), trailing: IconButton(icon: const Icon(Icons.delete), onPressed: () { setState(() => pls.removeAt(i)); _save(); }))),
      floatingActionButton: FloatingActionButton(onPressed: () { final ctrl = TextEditingController(); showDialog(context: context, builder: (c) => AlertDialog(title: const Text('New Playlist'), content: TextField(controller: ctrl, decoration: const InputDecoration(hintText: 'Playlist name')), actions: [TextButton(onPressed: () { setState(() => pls.add(Playlist(name: ctrl.text, paths: []))); _save(); Navigator.pop(context); }, child: const Text('Create'))])); }, child: const Icon(Icons.add)));
  }
}
