import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:media_kit/media_kit.dart';
import 'package:media_kit_video/media_kit_video.dart';
import 'package:provider/provider.dart';
import 'package:screen_brightness/screen_brightness.dart';
import '../models/media_item.dart';
import '../services/settings_service.dart';

class PlayerScreen extends StatefulWidget {
  final MediaItem item; final List<MediaItem> queue;
  const PlayerScreen({super.key, required this.item, required this.queue});
  @override State<PlayerScreen> createState() => _PlayerScreenState();
}
class _PlayerScreenState extends State<PlayerScreen> {
  late final Player player; late final VideoController controller;
  bool showUI = true; bool audioOnly = false; bool locked = false;
  double brightness = 0.5; double volume = 1; String seekLabel = '';
  Timer? hideTimer; Timer? seekTimer; double dragStartY = 0; bool isLeftDrag = false;
  MediaItem get current => widget.item;
  @override void initState() {
    super.initState();
    player = Player(configuration: const PlayerConfiguration(title: 'MaxPlayer', ready: true));
    controller = VideoController(player);
    _open(widget.item); _hideAfter();
  }
  Future<void> _open(MediaItem it) async {
    final s = context.read<AppSettings>();
    s.lastPath = it.path; s.lastIsAudio = it.isAudio; await s.save();
    await player.open(Media(it.path), play: true);
  }
  void _hideAfter() { hideTimer?.cancel(); hideTimer = Timer(const Duration(seconds: 3), () { if (mounted) setState(() => showUI = false); }); }
  void _toggle() { setState(() => showUI = !showUI); if (showUI) _hideAfter(); }
  Future<void> _fastSeek(int sec) async {
    final pos = await player.stream.position.first;
    final dur = await player.stream.duration.first;
    var target = pos + Duration(seconds: sec);
    if (target < Duration.zero) target = Duration.zero;
    if (dur != Duration.zero && target > dur) target = dur;
    await player.seek(target);
    setState(() => seekLabel = '${sec > 0 ? '+' : ''}$sec s');
    seekTimer?.cancel(); seekTimer = Timer(const Duration(milliseconds: 800), () { if (mounted) setState(() => seekLabel = ''); });
  }
  void _onDoubleTap(TapDownDetails d, bool isRight) {
    final size = MediaQuery.of(context).size; final y = d.globalPosition.dy; final x = d.globalPosition.dx;
    if (y < size.height * 0.28 || y > size.height * 0.72) return;
    if (x < 60 || x > size.width - 60) return;
    final s = context.read<AppSettings>(); if (!s.doubleTapSeek) return;
    _fastSeek(isRight ? s.seekSeconds : -s.seekSeconds);
  }
  void _onDragStart(DragStartDetails d) { dragStartY = d.globalPosition.dy; isLeftDrag = d.globalPosition.dx < MediaQuery.of(context).size.width / 2; }
  Future<void> _onDragUpdate(DragUpdateDetails d) async {
    final s = context.read<AppSettings>();
    if (isLeftDrag && !s.swipeBrightness) return; if (!isLeftDrag && !s.swipeVolume) return;
    final delta = (dragStartY - d.globalPosition.dy) / 300;
    if (isLeftDrag) { brightness = (brightness + delta).clamp(0.05, 1.0); await ScreenBrightness().setScreenBrightness(brightness); }
    else { volume = (volume + delta).clamp(0, 1); await player.setVolume(volume * 100); }
    setState(() {});
  }
  @override void dispose() { final st = context.read<AppSettings>(); st.lastPositionMs = player.state.position.inMilliseconds; st.save(); player.dispose(); hideTimer?.cancel(); super.dispose(); }
  @override Widget build(BuildContext context) {
    final s = context.watch<AppSettings>();
    return Scaffold(backgroundColor: Colors.black, body: GestureDetector(
      onTap: _toggle,
      onDoubleTapDown: (d) { final w = MediaQuery.of(context).size.width; _onDoubleTap(d, d.globalPosition.dx > w / 2); },
      onVerticalDragStart: _onDragStart, onVerticalDragUpdate: _onDragUpdate,
      child: Stack(children: [
        Center(child: audioOnly ? const Icon(Icons.music_note, size: 120, color: Colors.white) : Video(controller: controller)),
        if (seekLabel.isNotEmpty) Center(child: Container(padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10), decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(20)), child: Text(seekLabel, style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)))),
        if (showUI) ...[
          Positioned(top: 0, left: 0, right: 0, child: Container(color: Colors.black45, padding: const EdgeInsets.fromLTRB(8, 28, 8, 8), child: Row(children: [IconButton(icon: const Icon(Icons.arrow_back, color: Colors.white), onPressed: () => Navigator.pop(context)), Expanded(child: Text(widget.item.name, style: TextStyle(color: Colors.white, fontSize: s.fontSize), maxLines: 1, overflow: TextOverflow.ellipsis)), IconButton(icon: const Icon(Icons.settings, color: Colors.white), onPressed: _showQuickSettings)]))),
          Positioned(top: 90, left: 0, right: 0, child: SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: [
            _toolBtn(Icons.headphones, 'Audio Only', () => setState(() => audioOnly = !audioOnly), audioOnly),
            _toolBtn(Icons.screen_rotation, 'Rotate', () { final o = MediaQuery.of(context).orientation; SystemChrome.setPreferredOrientations(o == Orientation.portrait ? [DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight] : [DeviceOrientation.portraitUp]); }),
            _toolBtn(Icons.picture_in_picture_alt, 'PiP', () {}),
            _toolBtn(Icons.equalizer, 'Equalizer', _showEQ),
            _toolBtn(Icons.lock, 'Lock', () => setState(() => locked = !locked), locked),
          ]))),
          Positioned(bottom: 0, left: 0, right: 0, child: Container(color: Colors.black54, padding: const EdgeInsets.all(10), child: Column(children: [
            StreamBuilder<Duration>(stream: player.stream.position, builder: (c, snap) { final pos = snap.data ?? Duration.zero; return StreamBuilder<Duration>(stream: player.stream.duration, builder: (c2, snap2) { final dur = snap2.data ?? Duration.zero; return Column(children: [Slider(value: dur.inMilliseconds == 0 ? 0 : pos.inMilliseconds.clamp(0, dur.inMilliseconds).toDouble(), max: dur.inMilliseconds.toDouble(), onChanged: (v) => player.seek(Duration(milliseconds: v.toInt())), activeColor: Colors.blue), Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(_fmt(pos), style: const TextStyle(color: Colors.white)), Text(_fmt(dur), style: const TextStyle(color: Colors.white))])]); }); }),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [IconButton(icon: const Icon(Icons.skip_previous, color: Colors.white, size: 32), onPressed: _prev), StreamBuilder<bool>(stream: player.stream.playing, builder: (c, snap) { final playing = snap.data ?? false; return IconButton(icon: Icon(playing ? Icons.pause : Icons.play_arrow, color: Colors.white, size: 42), onPressed: () => playing ? player.pause() : player.play()); }), IconButton(icon: const Icon(Icons.skip_next, color: Colors.white, size: 32), onPressed: _next)]),
          ]))),
        ],
      ])));
  }
  Widget _toolBtn(IconData i, String l, VoidCallback on, [bool active = false]) => Padding(padding: const EdgeInsets.symmetric(horizontal: 4), child: ActionChip(label: Text(l, style: const TextStyle(color: Colors.white)), avatar: Icon(i, color: Colors.white, size: 18), backgroundColor: active ? Colors.blue : Colors.black54, onPressed: on));
  String _fmt(Duration d) => '${d.inMinutes}:${(d.inSeconds % 60).toString().padLeft(2, '0')}';
  void _prev() { final idx = widget.queue.indexWhere((e) => e.path == widget.item.path); if (idx > 0) _open(widget.queue[idx - 1]); }
  void _next() { final idx = widget.queue.indexWhere((e) => e.path == widget.item.path); if (idx >= 0 && idx < widget.queue.length - 1) _open(widget.queue[idx + 1]); }
  void _showQuickSettings() { showModalBottomSheet(context: context, builder: (c) { final s = context.read<AppSettings>(); return Container(padding: const EdgeInsets.all(16), child: Column(mainAxisSize: MainAxisSize.min, children: [const Text('Player Settings', style: TextStyle(fontWeight: FontWeight.bold)), ListTile(title: const Text('Double-tap seek seconds'), trailing: DropdownButton<int>(value: s.seekSeconds, items: [for (final v in [5, 10, 15, 20, 30]) DropdownMenuItem(value: v, child: Text('$v sec'))], onChanged: (v) { if (v != null) s.setSeek(v); Navigator.pop(context); })), SwitchListTile(title: const Text('Resume playback'), value: s.resumePlayback, onChanged: (v) { s.resumePlayback = v; s.save(); }), SwitchListTile(title: const Text('Auto-play next'), value: s.autoPlayNext, onChanged: (v) { s.autoPlayNext = v; s.save(); })])); }); }
  void _showEQ() { showModalBottomSheet(context: context, builder: (c) => Container(padding: const EdgeInsets.all(16), child: Column(mainAxisSize: MainAxisSize.min, children: [const Text('Equalizer - 5 Band', style: TextStyle(fontWeight: FontWeight.bold)), Row(children: [for (int i = 0; i < 5; i++) Expanded(child: Column(children: [Text(['60Hz','230Hz','910Hz','3.6k','14k'][i]), Slider(value: 0, min: -12, max: 12, onChanged: (_) {})]))])]))); }
}
