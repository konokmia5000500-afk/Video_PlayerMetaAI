import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/settings_service.dart';
class SettingsScreen extends StatelessWidget { const SettingsScreen({super.key});
  @override Widget build(BuildContext context) {
    final s = context.watch<AppSettings>();
    return ListView(padding: const EdgeInsets.all(12), children: [
      const Text('Appearance', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
      ListTile(title: const Text('Theme Mode'), trailing: DropdownButton<String>(value: s.themeMode, items: const [DropdownMenuItem(value: 'system', child: Text('System')), DropdownMenuItem(value: 'dark', child: Text('Dark')), DropdownMenuItem(value: 'light', child: Text('Light'))], onChanged: (v) { if (v != null) { s.themeMode = v; s.save(); } })),
      ListTile(title: const Text('App Theme'), trailing: DropdownButton<String>(value: s.appTheme, items: const [DropdownMenuItem(value: 'blue', child: Text('Blue')), DropdownMenuItem(value: 'purple', child: Text('Purple')), DropdownMenuItem(value: 'green', child: Text('Green'))], onChanged: (v) { if (v != null) { s.appTheme = v; s.save(); } })),
      ListTile(title: const Text('Font Size'), trailing: SizedBox(width: 160, child: Slider(value: s.fontSize, min: 12, max: 22, onChanged: (v) { s.fontSize = v; s.save(); }))),
      const Divider(), const Text('Playback', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
      ListTile(title: const Text('Double-tap seek'), subtitle: Text('${s.seekSeconds} seconds'), trailing: const Icon(Icons.chevron_right), onTap: () { showModalBottomSheet(context: context, builder: (c) => Container(padding: const EdgeInsets.all(16), child: Column(mainAxisSize: MainAxisSize.min, children: [for (final v in [5, 10, 15, 20, 30]) ListTile(title: Text('$v seconds'), leading: Radio<int>(value: v, groupValue: s.seekSeconds, onChanged: (x) { if (x != null) s.setSeek(x); Navigator.pop(context); }))]))); }),
      SwitchListTile(title: const Text('Double-tap seek enabled'), value: s.doubleTapSeek, onChanged: (v) { s.doubleTapSeek = v; s.save(); }),
      SwitchListTile(title: const Text('Swipe for Volume'), value: s.swipeVolume, onChanged: (v) { s.swipeVolume = v; s.save(); }),
      SwitchListTile(title: const Text('Swipe for Brightness'), value: s.swipeBrightness, onChanged: (v) { s.swipeBrightness = v; s.save(); }),
      SwitchListTile(title: const Text('Resume playback'), value: s.resumePlayback, onChanged: (v) { s.resumePlayback = v; s.save(); }),
      SwitchListTile(title: const Text('Auto-play next video'), value: s.autoPlayNext, onChanged: (v) { s.autoPlayNext = v; s.save(); }),
      ListTile(title: const Text('Orientation on open'), trailing: DropdownButton<String>(value: s.orientationMode, items: const [DropdownMenuItem(value: 'video', child: Text('Video size')), DropdownMenuItem(value: 'landscape', child: Text('Landscape')), DropdownMenuItem(value: 'portrait', child: Text('Portrait')), DropdownMenuItem(value: 'system', child: Text('System default')), DropdownMenuItem(value: 'sensor', child: Text('Sensor'))], onChanged: (v) { if (v != null) { s.orientationMode = v; s.save(); } })),
      ListTile(title: const Text('Sort by'), trailing: DropdownButton<String>(value: s.sortBy, items: const [DropdownMenuItem(value: 'date', child: Text('Date')), DropdownMenuItem(value: 'name', child: Text('Name')), DropdownMenuItem(value: 'size', child: Text('Size'))], onChanged: (v) { if (v != null) { s.sortBy = v; s.save(); } })),
      const Divider(), const Text('About', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)), const ListTile(title: Text('Max Player Clone v1.0'), subtitle: Text('Fast - Smooth - No re-buffer on seek')),
    ]);
  }
}
