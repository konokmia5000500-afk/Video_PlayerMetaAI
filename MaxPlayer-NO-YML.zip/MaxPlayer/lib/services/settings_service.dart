import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
class AppSettings extends ChangeNotifier {
  int seekSeconds = 10; bool doubleTapSeek = true;
  bool swipeVolume = true; bool swipeBrightness = true;
  bool resumePlayback = true; bool autoPlayNext = true;
  String orientationMode = 'video'; String themeMode = 'system'; String appTheme = 'blue';
  double fontSize = 15; String sortBy = 'date';
  String lastPath = ''; int lastPositionMs = 0; bool lastIsAudio = false;
  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    seekSeconds = p.getInt('seek') ?? 10; doubleTapSeek = p.getBool('dt') ?? true;
    swipeVolume = p.getBool('sv') ?? true; swipeBrightness = p.getBool('sb') ?? true;
    resumePlayback = p.getBool('resume') ?? true; autoPlayNext = p.getBool('next') ?? true;
    orientationMode = p.getString('orient') ?? 'video'; themeMode = p.getString('themeMode') ?? 'system';
    appTheme = p.getString('appTheme') ?? 'blue'; fontSize = p.getDouble('font') ?? 15;
    sortBy = p.getString('sort') ?? 'date'; lastPath = p.getString('lastPath') ?? '';
    lastPositionMs = p.getInt('lastPos') ?? 0; notifyListeners();
  }
  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setInt('seek', seekSeconds); await p.setBool('dt', doubleTapSeek);
    await p.setBool('sv', swipeVolume); await p.setBool('sb', swipeBrightness);
    await p.setBool('resume', resumePlayback); await p.setBool('next', autoPlayNext);
    await p.setString('orient', orientationMode); await p.setString('themeMode', themeMode);
    await p.setString('appTheme', appTheme); await p.setDouble('font', fontSize);
    await p.setString('sort', sortBy); await p.setString('lastPath', lastPath);
    await p.setInt('lastPos', lastPositionMs); notifyListeners();
  }
  void setSeek(int v) { seekSeconds = v; save(); }
  ThemeMode get themeModeEnum => themeMode == 'dark' ? ThemeMode.dark : themeMode == 'light' ? ThemeMode.light : ThemeMode.system;
  Color get accent => appTheme == 'purple' ? Colors.purple : appTheme == 'green' ? Colors.green : const Color(0xFF1A5CFF);
}
