import 'dart:io';
import 'package:path/path.dart' as p;
import '../models/media_item.dart';
class MediaService {
  static const videoExt = {'.mp4','.mkv','.webm','.avi','.mov','.3gp','.m4v','.flv'};
  static const audioExt = {'.mp3','.m4a','.wav','.flac','.aac','.ogg','.opus','.wma'};
  static Future<List<MediaItem>> scan() async {
    List<MediaItem> out = [];
    final roots = [Directory('/storage/emulated/0/Movies'), Directory('/storage/emulated/0/Download'), Directory('/storage/emulated/0/DCIM'), Directory('/storage/emulated/0')];
    for (final r in roots) {
      if (!await r.exists()) continue;
      await for (final e in r.list(recursive: true, followLinks: false)) {
        try {
          if (e is File) {
            final ext = p.extension(e.path).toLowerCase();
            if (videoExt.contains(ext) || audioExt.contains(ext)) {
              final st = await e.stat();
              out.add(MediaItem(path: e.path, name: p.basename(e.path), folder: p.dirname(e.path), isAudio: audioExt.contains(ext), size: st.size, modified: st.modified));
            }
          }
        } catch (_) {}
        if (out.length > 2000) break;
      }
      if (out.length > 800) break;
    }
    return out;
  }
  static Map<String, List<MediaItem>> groupByFolder(List<MediaItem> items, bool audio) {
    Map<String, List<MediaItem>> m = {};
    for (final i in items) { if (i.isAudio != audio) continue; m.putIfAbsent(i.folder, () => []).add(i); }
    return m;
  }
}
