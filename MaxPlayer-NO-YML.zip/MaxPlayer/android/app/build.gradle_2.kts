plugins { id("com.android.application"); id("kotlin-android"); id("dev.flutter.flutter-gradle-plugin") }
android {
    namespace = "com.maxplayer.clone"
    compileSdk = 34
    ndkVersion = "25.1.8937393"
    defaultConfig {
        applicationId = "com.maxplayer.clone"
        minSdk = 21
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        ndk { abiFilters += listOf("arm64-v8a") }
    }
    buildTypes { release { signingConfig = signingConfigs.getByName("debug") } }
}
flutter { source = "../.." }
